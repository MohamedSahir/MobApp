import { InMemoryDbService } from 'angular-in-memory-web-api';

import { Product } from './product';

export class ProductData implements InMemoryDbService {

    createDb() {
        const products: Product[] = [
            {
                'id': 1,
                'productName': 'Samsung Galaxy',
                'productCode': '3',
                // tslint:disable-next-line:max-line-length
                'description': 'The Samsung Galaxy S III (or Galaxy S3) is a Android smartphone designed, developed, and marketed by Samsung Electronics. ... Depending on country, the 4.8-inch (120 mm) smartphone comes with different processors and RAM capacity, and 4G LTE support ',
                'starRating': 3.2
            },
            {
                'id': 2,
                'productName': 'Iphone 7',
                'productCode': 'GDN-0023',
                 // tslint:disable-next-line:max-line-length
                'description': '1The iPhone 7 is smaller with a 4.7-inch screen, while the iPhone 7 Plus has a 5.5-inch screen. Both devices are powered by Apples A10 Fusion chip, a 64-bit architecture the company says is 40 percent faster than the A9 in the iPhone 6S and the 6S Plus. ... Both have a quad-core processor — a first for iPhone.',
                'starRating': 4.2
            },
            {
                'id': 5,
                'productName': 'Hammer',
                'productCode': 'TBX-0048',
                'description': 'Curved claw steel hammer',
                'starRating': 4.8
            },
            {
                'id': 8,
                'productName': 'Saw',
                'productCode': 'TBX-0022',
                'description': '15-inch steel blade hand saw',
                'starRating': 3.7
            },
            {
                'id': 10,
                'productName': 'Video Game Controller',
                'productCode': 'GMG-0042',
                'description': 'Standard two-button video game controller',
                'starRating': 4.6
            }
        ];
        return { products };
    }
}
